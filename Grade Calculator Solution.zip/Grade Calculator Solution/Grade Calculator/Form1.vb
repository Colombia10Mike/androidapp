﻿' Copyright (c) 2019 Union County College. All Rights Reserved.
' CST-130-051 Visual Basic
'
' Name:               Grade Calculator
' Purpose:            Final Project
' Programmer:         Michael Sarria


Option Explicit On
Option Infer Off
Option Strict On


Public Class FrmSarria
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim dblGrade As Double
        Dim blnResult As Boolean
        Dim strLetterGrade As String

        blnResult = Double.TryParse(txtGrades.Text, dblGrade)

        If ((blnResult = True) And dblGrade >= 0 And (dblGrade <= 100)) Then


            Select Case (dblGrade)
                Case Is >= 95
                    strLetterGrade = "A+"
                Case Is >= 90
                    strLetterGrade = "A"
                Case 85 To 90
                    strLetterGrade = "B+"
                Case 80 To 85
                    strLetterGrade = "B"
                Case 75 To 79
                    strLetterGrade = "C+"
                Case 70 To 75
                    strLetterGrade = "C"
                Case 65 To 70
                    strLetterGrade = "D+"
                Case 60 To 65
                    strLetterGrade = "D"
                Case Else
                    strLetterGrade = "F"
            End Select

        Else
            'false case 
            txtMessage.Text = "please Enter a Number >=0 and <=100"
        End If

        'Show Grade to the User
        txtLetterGrades.Text = strLetterGrade
    End Sub

    Private Sub txtGrades_TextChanged(sender As Object, e As EventArgs) Handles txtGrades.TextChanged
        txtMessage.Text = ""
        txtLetterGrades.Text = ""
    End Sub

    Private Sub txtGrades_keyPress(sender As Object, e As KeyPressEventArgs) Handles txtGrades.KeyPress
        Debug.Print("Key Typed:" & e.KeyChar & "KeyCode:" & Asc(e.KeyChar))

        If ((e.KeyChar < "0") Or (e.KeyChar > "9")) And (e.KeyChar <> ControlChars.Back) Then
            e.Handled = True
        End If
    End Sub

End Class
